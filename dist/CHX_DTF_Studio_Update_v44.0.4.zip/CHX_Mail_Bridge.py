#!/usr/bin/env python3
"""CHX DTF Studio mail bridge. LOCALHOST ONLY. Python 3 + reportlab required.
No invoice data or SMTP password is sent to third-party APIs. One.com SMTP is the only network destination when explicitly sending.
"""
from __future__ import annotations
import datetime as dt
import base64
import hashlib
import hmac
import http.cookies
import secrets
import time
import html
import io
import json
import os
from pathlib import Path
import re
import smtplib
import ssl
import subprocess
import sys
import threading
import webbrowser
from email.message import EmailMessage
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
import CHX_Updater
APP_VERSION = os.environ.get('CHX_APP_VERSION','44.0.2')

BASE = Path(__file__).resolve().parent
PORT = int(os.environ.get('CHX_PORT','8765'))
APP_NAME = 'CHX_DTF_Studio.html'
SERVICE = 'CHX DTF Studio SMTP (one.com)'
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
RENDER_LOCK = threading.RLock()

def valid_email(s):
    return isinstance(s,str) and bool(EMAIL_RE.fullmatch(s)) and len(s)<255 and '\n' not in s and '\r' not in s

def secret_get(email):
    if sys.platform!='darwin':
        raise RuntimeError('Mac Keychain is required for credential storage.')
    r=subprocess.run(['security','find-generic-password','-s',SERVICE,'-a',email.lower(),'-w'],capture_output=True,text=True,timeout=15)
    if r.returncode != 0:
        return None
    return r.stdout.rstrip('\n')

def secret_set(email, password):
    if sys.platform!='darwin':
        raise RuntimeError('Mac Keychain is required for credential storage.')
    if not isinstance(password,str) or len(password)<4 or len(password)>512:
        raise ValueError('Enter a valid email password.')
    # No password in HTML, localStorage, archive, server log or command file. Sent directly to local Keychain tool.
    r=subprocess.run(['security','add-generic-password','-U','-s',SERVICE,'-a',email.lower(),'-w',password],capture_output=True,text=True,timeout=25)
    if r.returncode:
        raise RuntimeError('macOS Keychain declined the operation. Open Keychain Access and try again.')

def esc(s):
    return html.escape(str(s or ''),quote=False).replace('\n','<br/>')

def money(n):
    return f"{float(n or 0):,.2f} EUR".replace(',',' ')  # PDF uses fixed decimal dot.

def fmt_date(iso,language):
    try:
        d=dt.date.fromisoformat(iso)
        return d.strftime('%d-%m-%Y') if language=='nl' else d.strftime('%d %b %Y')
    except Exception:
        return str(iso or '')

def tax_label(code,lang):
    labels={
       '21':('21% VAT','21% btw'),'9':('9% VAT','9% btw'),'0':('0% VAT','0% btw'),
       'exempt':('VAT exempt','Vrijgesteld'),'rc':('VAT reverse charged','Btw verlegd'),
       'euService':('Reverse charge (EU service)','Verlegd (EU-dienst)'),
       'icl':('Intra-EU goods (0%)','Intracommunautaire levering (0%)'),
       'export':('Export outside EU (0%)','Uitvoer buiten EU (0%)'),
       'outside':('Outside NL VAT','Buiten NL btw-sfeer'),
       'kor':('VAT exempt (KOR)','Vrijgesteld (KOR)')
    }
    return labels.get(str(code),(str(code),str(code)))[1 if lang=='nl' else 0]

def invoice_pdf_bytes(record):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_LEFT, TA_RIGHT
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.colors import HexColor

    with RENDER_LOCK:
        fontname='Helvetica'
        boldname='Helvetica-Bold'
        candidates=[
          ('/System/Library/Fonts/Supplemental/Arial.ttf','/System/Library/Fonts/Supplemental/Arial Bold.ttf'),
          ('/Library/Fonts/Arial.ttf','/Library/Fonts/Arial Bold.ttf'),
          ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
        ]
        for normal,bold in candidates:
            if os.path.isfile(normal):
                try:
                    if 'CHXFont' not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont('CHXFont',normal))
                    fontname='CHXFont'
                    if os.path.isfile(bold):
                        if 'CHXFontBold' not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont('CHXFontBold',bold))
                        boldname='CHXFontBold'
                    else:boldname=fontname
                    break
                except Exception:pass

        lang='nl' if record.get('docLang')=='nl' else 'en'
        nl=lang=='nl'
        labels={
          'title':'FACTUUR' if nl else 'INVOICE','date':'Factuurdatum' if nl else 'Invoice date',
          'due':'Vervaldatum' if nl else 'Due date','delivery':'Leverdatum' if nl else 'Delivery date',
          'seller':'VAN' if nl else 'FROM','bill':'FACTUUR AAN' if nl else 'BILL TO',
          'desc':'Omschrijving' if nl else 'Description','qty':'Aantal' if nl else 'Qty',
          'unit':'Eenheidsprijs' if nl else 'Unit price','vat':'Btw' if nl else 'VAT',
          'amount':'Bedrag excl. btw' if nl else 'Amount excl. VAT','sub':'Subtotaal excl. btw' if nl else 'Subtotal excl. VAT',
          'total':'Totaal te betalen' if nl else 'Total due','payment':'BETAALGEGEVENS' if nl else 'PAYMENT DETAILS',
          'holder':'Rekeninghouder' if nl else 'Account holder','reference':'Betalingskenmerk' if nl else 'Payment reference'
        }
        orange=HexColor('#D96633')
        grey=HexColor('#64706D')
        ink=HexColor('#17201E')
        lines=record.get('items') or []
        if not isinstance(lines,list) or not lines or len(lines)>200:
            raise ValueError('Invoice must contain between 1 and 200 items.')
        if len(str(record.get('number','')))>100:raise ValueError('Invoice number too long.')
        seller=record.get('seller') or {}
        buf=io.BytesIO()
        doc=SimpleDocTemplate(buf,pagesize=A4,leftMargin=17*mm,rightMargin=17*mm,topMargin=19*mm,bottomMargin=17*mm,title=f"{labels['title']} {record.get('number','')}",author=str(seller.get('name','CHX')))
        styles={
          'normal':ParagraphStyle('xnormal',fontName=fontname,fontSize=9.3,leading=14,textColor=ink,spaceAfter=0),
          'small':ParagraphStyle('xsmall',fontName=fontname,fontSize=8.2,leading=11.8,textColor=ink),
          'muted':ParagraphStyle('xmuted',fontName=fontname,fontSize=8.5,leading=12,textColor=grey),
          'h':ParagraphStyle('xh',fontName=boldname,fontSize=20,leading=24,textColor=orange),
          'section':ParagraphStyle('xsection',fontName=boldname,fontSize=9,leading=13,textColor=ink),
          'thead':ParagraphStyle('xthead',fontName=boldname,fontSize=7.6,leading=10,textColor=grey),
          'bold':ParagraphStyle('xbold',fontName=boldname,fontSize=10,leading=14,textColor=ink),
          'boldlarge':ParagraphStyle('xboldlarge',fontName=boldname,fontSize=13,leading=17,textColor=ink),
        }
        P=lambda txt,style='normal':Paragraph(esc(txt),styles[style])
        story=[]
        head=Table([[P(labels['title'],'h'),P(str(record.get('number','')),'boldlarge')]],colWidths=[98*mm,74*mm])
        head.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(1,0),(1,0),'RIGHT'),('BOTTOMPADDING',(0,0),(-1,-1),11),('LINEBELOW',(0,-1),(-1,-1),2.5,orange)]))
        story.extend([head,Spacer(1,11)])
        metadata=[(labels['date'],fmt_date(record.get('date'),lang)),(labels['due'],fmt_date(record.get('due'),lang))]
        if record.get('delivery') and record['delivery']!=record.get('date'):
            metadata.append((labels['delivery'],fmt_date(record['delivery'],lang)))
        mtab=Table([[P(a,'muted'),P(b)] for a,b in metadata],colWidths=[45*mm,127*mm])
        mtab.setStyle(TableStyle([('BOTTOMPADDING',(0,0),(-1,-1),4)]))
        story.extend([mtab,Spacer(1,16)])
        def business_box(label,name,address,extras):
            parts=[P(label,'section'),Spacer(1,6),P(name,'bold')]
            if address:parts.append(P(address))
            for key,value in extras:
                if value:parts.append(P(f'{key}: {value}','small'))
            return parts
        seller_info=business_box(labels['seller'],seller.get('name',''),seller.get('address',''), [('KvK',seller.get('kvk')),('VAT ID' if not nl else 'Btw-ID',seller.get('vatId')),('Email',seller.get('email'))])
        buyer_info=business_box(labels['bill'],record.get('client',''),record.get('address',''), [('Contact',record.get('clientContact')),('KvK',record.get('clientKvk')),('VAT ID' if not nl else 'Btw-ID',record.get('clientVat')),('Email',record.get('clientEmail')),('Phone' if not nl else 'Telefoon',record.get('clientPhone'))])
        side=Table([[seller_info,buyer_info]],colWidths=[86*mm,86*mm])
        side.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        story.extend([side,Spacer(1,20)])
        row_data=[[P(labels['desc'],'thead'),P(labels['qty'],'thead'),P(labels['unit'],'thead'),P(labels['vat'],'thead'),P(labels['amount'],'thead')]]
        for line in lines:
            desc=str(line.get('desc',''))
            if len(desc)>2000:raise ValueError('Description too long.')
            discount=line.get('discountPct',0)
            if float(discount or 0)>0:desc+=f"\n{('Korting' if nl else 'Discount')} {discount}%"
            qty=line.get('qty',0)
            row_data.append([P(desc,'small'),P(str(qty),'small'),P(money(line.get('unitNet',0)),'small'),P(tax_label(line.get('rate','21'),lang),'small'),P(money(line.get('subtotal',0)),'small')])
        rows=Table(row_data,colWidths=[66*mm,17*mm,35*mm,28*mm,26*mm],repeatRows=1,hAlign='LEFT')
        rows.setStyle(TableStyle([
          ('BACKGROUND',(0,0),(-1,0),HexColor('#F3F3F1')),
          ('VALIGN',(0,0),(-1,-1),'TOP'),
          ('LINEBELOW',(0,0),(-1,0),.5,HexColor('#D1D6D2')),
          ('LINEBELOW',(0,1),(-1,-1),.35,HexColor('#E2E6E3')),
          ('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),
          ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5)
        ]))
        story.extend([rows,Spacer(1,13)])
        grouped={}
        for line in lines:
            code=str(line.get('rate','21'))
            if code not in grouped:grouped[code]=[0,0]
            grouped[code][0]+=float(line.get('subtotal') or 0)
            grouped[code][1]+=float(line.get('vat') or 0)
        totals=[(labels['sub'],money(record.get('subtotal',0)))]
        totals.extend([(tax_label(code,lang),money(values[1])) for code,values in grouped.items()])
        totals.append((labels['total'],money(record.get('total',0))))
        tt=Table([[P(k,'bold' if i==len(totals)-1 else 'muted'),P(v,'boldlarge' if i==len(totals)-1 else 'bold')] for i,(k,v) in enumerate(totals)],colWidths=[104*mm,68*mm])
        tt.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('ALIGN',(1,0),(-1,-1),'RIGHT'),('LINEABOVE',(0,-1),(-1,-1),1.3,orange),('TOPPADDING',(0,-1),(-1,-1),11),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.extend([tt,Spacer(1,20)])
        bank=[P(labels['payment'],'section')]
        for a,b in [(labels['holder'],seller.get('accountHolder') or seller.get('name')),('IBAN',seller.get('iban')),('BIC / SWIFT',seller.get('bic')),(labels['reference'],record.get('number'))]:
            if b:bank.append(P(f'{a}: {b}','small'))
        payment=Table([[bank]],colWidths=[172*mm])
        payment.setStyle(TableStyle([('BOX',(0,0),(-1,-1),.5,HexColor('#E3D4CC')),('LINEBEFORE',(0,0),(0,0),3,orange),('BACKGROUND',(0,0),(-1,-1),HexColor('#FCF9F7')),('LEFTPADDING',(0,0),(-1,-1),14),('RIGHTPADDING',(0,0),(-1,-1),14),('TOPPADDING',(0,0),(-1,-1),13),('BOTTOMPADDING',(0,0),(-1,-1),13)]))
        story.extend([payment,Spacer(1,15)])
        taxNotes={'0':'0% btw-tarief.' if nl else '0% VAT rate.', 'exempt':'Vrijgesteld van btw.' if nl else 'VAT exempt.', 'rc':'Btw verlegd.' if nl else 'Reverse charge.', 'euService':'Btw verlegd – intracommunautaire dienst.' if nl else 'Reverse charge – intra-EU service.', 'icl':'Intracommunautaire levering.' if nl else 'Intra-Community supply.', 'export':'0% btw – uitvoer van goederen buiten EU.' if nl else '0% VAT – export outside the EU.', 'outside':'Niet belast met Nederlandse btw.' if nl else 'Outside Dutch VAT scope.', 'kor':'Vrijgesteld van btw (KOR).' if nl else 'VAT exempt (KOR).'}
        foot=[taxNotes[code] for code in grouped if code in taxNotes]
        if record.get('note'):foot.append(str(record['note']))
        if foot:story.append(P('\n'.join(foot),'muted'))
        def page(canvas,doc):
            canvas.saveState();canvas.setStrokeColor(HexColor('#E2E6E3'));canvas.line(17*mm,13*mm,193*mm,13*mm)
            canvas.setFont(fontname,7.4);canvas.setFillColor(grey)
            canvas.drawRightString(193*mm,9*mm,f"{record.get('number','')} · {doc.page}")
            canvas.restoreState()
        doc.build(story,onFirstPage=page,onLaterPages=page)
        return buf.getvalue()

def send_invoice(record, recipient, copy_to, subject, body, pdf):
    seller=record.get('seller') or {}
    sender=str(seller.get('email') or '').strip().lower()
    from_saved=sender
    if not valid_email(sender):raise ValueError('The issuing business needs a valid email address.')
    if not valid_email(recipient) or recipient.lower()!=str(record.get('clientEmail') or '').lower():
        raise ValueError('Recipient does not match the email in the issued invoice. Edit contact data before issuing.')
    if not valid_email(copy_to) or copy_to.lower()!=sender:raise ValueError('CC must be the issuing business email.')
    password=secret_get(sender)
    if not password:raise RuntimeError('Connect the one.com account for this issuing business first.')
    if not isinstance(subject,str) or not 1<=len(subject)<=300 or '\n' in subject or '\r' in subject:raise ValueError('Invalid email subject.')
    if not isinstance(body,str) or not 1<=len(body)<=12000:raise ValueError('Invalid email message.')
    if not isinstance(pdf,bytes) or not pdf.startswith(b'%PDF-') or len(pdf)>4_000_000:
        raise ValueError('The prepared PDF is invalid.')
    message=EmailMessage()
    message['From']=sender
    message['To']=recipient
    message['Cc']=copy_to
    message['Subject']=subject
    message.set_content(body)
    invno=re.sub(r'[^\w.-]','_',str(record.get('number') or 'Invoice'))
    message.add_attachment(pdf,maintype='application',subtype='pdf',filename=f'Invoice-{invno}.pdf')
    # Strict TLS, no insecure fallback and no 3rd-party service.
    with smtplib.SMTP('send.one.com',587,timeout=35) as smtp:
        smtp.ehlo()
        smtp.starttls(context=ssl.create_default_context())
        smtp.ehlo()
        smtp.login(sender,password)
        failures=smtp.send_message(message)
        if failures:raise RuntimeError('SMTP rejected one or more recipients; check the addresses.')
    return pdf

# Application login gate. Master-password verifier is stored in the logged-in macOS
# user's Keychain (never the raw password). Sessions live only in memory and expire.
AUTH_SERVICE = 'CHX DTF Studio App Login v1'
AUTH_ACCOUNT = 'local-admin'
AUTH_TEST_FILE = os.environ.get('CHX_AUTH_TEST_FILE', '') if sys.platform != 'darwin' else ''
AUTH_LOCK = threading.RLock()
AUTH_SESSIONS = {}
AUTH_FAILURES = []
SESSION_IDLE_SECONDS = 30 * 60
PBKDF2_ITERATIONS = 600_000


def _auth_stored():
    if sys.platform == 'darwin':
        r = subprocess.run(['security','find-generic-password','-s',AUTH_SERVICE,
                            '-a',AUTH_ACCOUNT,'-w'], capture_output=True,text=True,timeout=12)
        if r.returncode:
            return None
        return r.stdout.strip()
    if AUTH_TEST_FILE:
        f = Path(AUTH_TEST_FILE)
        return f.read_text(encoding='utf-8').strip() if f.exists() else None
    raise RuntimeError('Login verification requires macOS Keychain.')


def _auth_save(verifier):
    if sys.platform == 'darwin':
        r = subprocess.run(['security','add-generic-password','-U','-s',AUTH_SERVICE,
                            '-a',AUTH_ACCOUNT,'-w',verifier],capture_output=True,text=True,timeout=20)
        if r.returncode:
            raise RuntimeError('macOS Keychain refused to save the login verifier.')
        return
    if AUTH_TEST_FILE:
        f=Path(AUTH_TEST_FILE);f.parent.mkdir(parents=True,exist_ok=True)
        fd=os.open(str(f),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as out:out.write(verifier)
        return
    raise RuntimeError('Login verifier storage is not available.')


def _password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(24)
    digest = hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,PBKDF2_ITERATIONS)
    return 'pbkdf2-sha256:{0}:{1}:{2}'.format(PBKDF2_ITERATIONS,
            base64.b64encode(salt).decode(),base64.b64encode(digest).decode())


def _password_valid(password, verifier):
    try:
        algo,iterations,salt_text,digest_text=verifier.split(':')
        if algo!='pbkdf2-sha256':return False
        n=int(iterations)
        if n<200000 or n>3000000:return False
        salt=base64.b64decode(salt_text,validate=True)
        expected=base64.b64decode(digest_text,validate=True)
        calculated=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,n)
        return hmac.compare_digest(expected,calculated)
    except Exception:return False


def _cookie_value(headers):
    try:
        cookies=http.cookies.SimpleCookie()
        cookies.load(headers.get('Cookie',''))
        morsel=cookies.get('chx_session')
        return morsel.value if morsel else ''
    except Exception:return ''


def _session_active(headers):
    token=_cookie_value(headers)
    if not token:return False
    with AUTH_LOCK:
        last=AUTH_SESSIONS.get(token)
        if last is None:return False
        now=time.monotonic()
        if now-last>SESSION_IDLE_SECONDS:
            AUTH_SESSIONS.pop(token,None)
            return False
        AUTH_SESSIONS[token]=now
        return True


def _login_attempt_allowed():
    with AUTH_LOCK:
        cutoff=time.monotonic()-60
        AUTH_FAILURES[:]=[x for x in AUTH_FAILURES if x>cutoff]
        return len(AUTH_FAILURES)<5


def _login_failure():
    with AUTH_LOCK:AUTH_FAILURES.append(time.monotonic())


def _login_page(configured):
    headline='Sign in' if configured else 'Create your studio password'
    info=('Enter your CHX DTF Studio password to unlock your invoices and calculator.'
          if configured else 'First launch: choose a password (at least 10 characters). It is not your one.com email password.')
    action='Unlock studio' if configured else 'Set password & open studio'
    extra='' if configured else '<label>Confirm password<input type="password" id="confirm" minlength="10" autocomplete="new-password" required></label>'
    mode='login' if configured else 'setup'
    auto='current-password' if configured else 'new-password'
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CHX DTF Studio · Secure access</title><style>
:root{{color-scheme:dark}}*{{box-sizing:border-box}}
body{{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(circle at 70% 0%,#214137 0%,#101c19 49%,#0b1211 100%);font:15px/1.5 system-ui,-apple-system,sans-serif;color:#eaf2ed;padding:20px}}
.panel{{width:min(440px,100%);border:1px solid #344740;border-radius:18px;background:#14221e;padding:32px;box-shadow:0 18px 55px #050a0955}}
.logo{{display:inline-flex;align-items:center;justify-content:center;border:2px solid #ff8958;width:69px;height:69px;color:#ff8958;font-size:20px;font-weight:900;letter-spacing:-1px;margin-bottom:17px}}
h1{{font-size:23px;margin:0 0 5px}}.intro{{color:#b0c5ba;margin:0 0 22px}}label{{display:block;color:#d6e4de;font-weight:650;margin:12px 0 0}}
input{{display:block;width:100%;height:45px;margin-top:6px;border-radius:8px;border:1px solid #3e5b50;background:#23382f;color:white;padding:0 12px;font:inherit}}
input:focus{{outline:2px solid #ff8958;outline-offset:1px}}button{{width:100%;padding:13px;margin-top:22px;background:#ff8958;color:#181c19;border:0;border-radius:8px;font-size:15px;font-weight:850;cursor:pointer}}
#msg{{color:#ffa699;min-height:24px;margin-top:10px}}footer{{font-size:12px;color:#96aea1;margin-top:21px}}
</style></head><body><div class="panel"><div class="logo">CHX</div><h1>{headline}</h1><p class="intro">{info}</p>
<form id="auth"><label>Studio password<input type="password" id="password" minlength="10" autocomplete="{auto}" required autofocus></label>{extra}
<button type="submit" id="submit">{action}</button><div id="msg" role="alert" aria-live="polite"></div></form>
<footer>Local Mac application · The login verifier stays in macOS Keychain. Invoice files are not encrypted by this password.</footer></div>
<script>
document.getElementById('auth').addEventListener('submit',async function(e){{
 e.preventDefault();let p=document.getElementById('password').value;
 let confirmEl=document.getElementById('confirm');
 let msg=document.getElementById('msg');msg.textContent='';
 if(confirmEl && confirmEl.value!==p){{msg.textContent='Passwords do not match.';return;}}
 let btn=document.getElementById('submit');btn.disabled=true;
 try{{let r=await fetch('/api/auth/{mode}',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{password:p}})}});
 let data=await r.json();if(!r.ok)throw new Error(data.error||'Could not sign in.');
 location.replace('/');
 }}catch(err){{msg.textContent=err.message||'Login failed';btn.disabled=false;}}
}});
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version='CHX-Secure-Local-Studio/2.0'
    def log_message(self,format,*args):
        # No invoice data, passwords, or login attempts in output.
        pass
    def _is_local(self):
        host=self.headers.get('Host','')
        return host in (f'127.0.0.1:{PORT}',f'localhost:{PORT}') and self.client_address[0] in ('127.0.0.1','::1')
    def _origin_ok(self):
        return self.headers.get('Origin') in (f'http://127.0.0.1:{PORT}',f'http://localhost:{PORT}')
    def _send(self,status,data,kind='application/json',cookie=None):
        self.send_response(status)
        self.send_header('Content-Type', f'{kind}; charset=utf-8' if kind not in ('application/pdf','application/octet-stream') else kind)
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','no-referrer')
        if kind=='text/html':
            self.send_header('Content-Security-Policy',"frame-ancestors 'none'")
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers()
        if kind=='application/json':data=json.dumps(data,ensure_ascii=False).encode('utf-8')
        elif isinstance(data,str):data=data.encode('utf-8')
        self.wfile.write(data)
    def _authorized(self):return _session_active(self.headers)
    def do_GET(self):
        if not self._is_local():return self._send(403,{'error':'Invalid local host'})
        path=urlsplit(self.path).path
        if path=='/api/auth/state':
            return self._send(200,{'configured':bool(_auth_stored()),'unlocked':self._authorized(),'version':APP_VERSION,'chxStudio':True})
        if path in ('/','/app','/'+APP_NAME):
            if not self._authorized():return self._send(200,_login_page(bool(_auth_stored())),'text/html')
            return self._send(200,(BASE/APP_NAME).read_bytes(),'text/html')
        if not self._authorized():return self._send(401,{'error':'Studio locked. Enter your password.'})
        if path=='/api/status':
            return self._send(200,{'ok':True,'service':'CHX Secure Mail Bridge','version':APP_VERSION,'pdf':True,'onecom':True,'updates':True})
        return self._send(404,{'error':'Not found'})
    def do_POST(self):
        if not self._is_local() or not self._origin_ok():return self._send(403,{'error':'Not authorized from this origin'})
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self._send(415,{'error':'JSON only'})
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<2 or size>600000:raise ValueError('Request too large.')
            data=json.loads(self.rfile.read(size))
            if not isinstance(data,dict):raise ValueError('Expected object.')
            path=urlsplit(self.path).path
            if path in ('/api/auth/setup','/api/auth/login'):
                supplied=data.get('password','')
                if not isinstance(supplied,str) or len(supplied)>1024:
                    raise ValueError('Invalid password.')
                if not _login_attempt_allowed():return self._send(429,{'error':'Too many attempts. Try again in one minute.'})
                with AUTH_LOCK:
                    verifier=_auth_stored()
                    if path=='/api/auth/setup':
                        if verifier:return self._send(409,{'error':'Studio password is already configured.'})
                        if len(supplied)<10:raise ValueError('Choose at least 10 characters.')
                        _auth_save(_password_hash(supplied))
                    else:
                        if not verifier:return self._send(409,{'error':'Set a studio password first.'})
                        if not _password_valid(supplied,verifier):
                            _login_failure()
                            return self._send(401,{'error':'Incorrect password.'})
                    token=secrets.token_urlsafe(32)
                    AUTH_SESSIONS[token]=time.monotonic()
                return self._send(200,{'ok':True},cookie=f'chx_session={token}; HttpOnly; SameSite=Strict; Path=/')
            if path=='/api/auth/logout':
                if not self._authorized():return self._send(401,{'error':'Already locked.'})
                with AUTH_LOCK:AUTH_SESSIONS.pop(_cookie_value(self.headers),None)
                return self._send(200,{'ok':True},cookie='chx_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
            if not self._authorized():return self._send(401,{'error':'Studio locked. Enter your password.'})
            if path=='/api/quit':
                self._send(200,{'ok':True,'stopping':True})
                threading.Thread(target=self.server.shutdown,daemon=True).start()
                return
            if path=='/api/updates/check':
                return self._send(200,CHX_Updater.check(APP_VERSION))
            if path=='/api/updates/install':
                ver=data.get('version')
                digest=data.get('digest')
                if not isinstance(ver,str) or not isinstance(digest,str):
                    raise ValueError('Missing release version or checksum.')
                return self._send(200,CHX_Updater.install(APP_VERSION,ver,digest))
            if path=='/api/account':
                email=str(data.get('email','')).strip().lower()
                if not valid_email(email):raise ValueError('Enter a valid one.com mailbox address.')
                secret_set(email,data.get('password'))
                return self._send(200,{'ok':True,'email':email,'keychain':True})
            if path=='/api/account-status':
                email=str(data.get('email','')).strip().lower()
                if not valid_email(email):raise ValueError('The issuing firm needs an email address.')
                return self._send(200,{'ok':True,'configured':bool(secret_get(email)),'email':email})
            if path=='/api/pdf':
                record=data.get('record')
                if not isinstance(record,dict):raise ValueError('Missing invoice record.')
                return self._send(200,invoice_pdf_bytes(record),'application/pdf')
            if path=='/api/send':
                record=data.get('record')
                if not isinstance(record,dict):raise ValueError('Missing invoice record.')
                blob=base64.b64decode(str(data.get('pdfBase64','')),validate=True)
                send_invoice(record,str(data.get('to','')).strip(),str(data.get('cc','')).strip(),str(data.get('subject','')).strip(),str(data.get('body','')).strip(),blob)
                return self._send(200,{'ok':True,'acceptedBySMTP':True,'recipient':data.get('to'),'cc':data.get('cc')})
            return self._send(404,{'error':'Unknown endpoint'})
        except (ValueError,RuntimeError,CHX_Updater.UpdateError) as e:return self._send(400,{'error':str(e)})
        except Exception as e:return self._send(500,{'error':f'Action failed ({e.__class__.__name__}).'})


def main():
    if not (BASE/APP_NAME).is_file():raise SystemExit('Cannot find CHX_DTF_Studio.html beside this script.')
    ThreadingHTTPServer.allow_reuse_address=True
    with ThreadingHTTPServer(('127.0.0.1',PORT),Handler) as server:
        print(f'CHX DTF Studio secure app at http://127.0.0.1:{PORT}/',flush=True)
        print('Local-only. A password is required before the studio or invoice endpoints can be accessed.',flush=True)
        if os.environ.get('CHX_NO_BROWSER')!='1':
            try:
                if sys.platform=='darwin':
                    subprocess.Popen(['open','-a','Google Chrome',f'http://127.0.0.1:{PORT}/'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                else:webbrowser.open(f'http://127.0.0.1:{PORT}/')
            except Exception:
                try:webbrowser.open(f'http://127.0.0.1:{PORT}/')
                except Exception:pass
        server.serve_forever()
if __name__=='__main__':main()
